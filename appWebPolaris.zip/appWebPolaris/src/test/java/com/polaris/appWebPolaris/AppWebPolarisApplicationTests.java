package com.polaris.appWebPolaris;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppWebPolarisApplicationTests {

	@Test
	void contextLoads() {
	}

}
